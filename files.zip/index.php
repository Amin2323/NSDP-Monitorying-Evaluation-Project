
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<script type="text/javascript" src="js/jquery-1.6.4/jquery-min.js"></script>
		<script type="text/javascript" src="js/jquery-ui-1.8.16.custom/js/jquery-ui-1.8.16.custom.min.js"></script>
		<link rel="stylesheet" type="text/css" href="js/jquery-ui-1.8.16.custom/css/ui-lightness/jquery-ui-1.8.16.custom.css" media="screen" />
		
		<script type="text/javascript" src="js/underscore-1.3.3/underscore-min.js"></script>
		<link rel="stylesheet" type="text/css" href="css/external/app.css" media="screen" />
		<script type="text/javascript" src="css/external/dropdown.js"></script>
				
        <title>National Skills Development Program</title>
		<script type="text/javascript">
			$(document).ready(function(){
				$("#eventStartDate").datepicker({dateFormat: 'dd-mm-yy'});
				$("#eventEndDate").datepicker({dateFormat: 'dd-mm-yy'});	
				$('#province').change(function(){
					$.getJSON("getDistricts.php?provinceId=" + $(this).val(), function(json) {
						$("#district").empty();
						_.each(json.districts, function(district){
							//console.log("District Id: " + district.id + ", District Name: " + district.name);
							$("#district").append("<option value=" + district.id + ">" + district.name + "</option>");
						});
					});
				});
			});
		</script>
</head>
<body>
<?php
	include("toolbar.php");
?>
  <div id="main">
	<div style="width: 40%; margin-TOP: 80px; margin-left: auto; margin-right: auto;">
		<h3>Add - Training Center</h3>
	</div>
	<div style="width: 40%; margin-TOP: 10px; margin-left: auto; margin-right: auto;">
	<form id="add-trainee" action="process-add-training.php" method="POST">
		<table>			
			<tr>
				<td>Province Name </td>
				<td>
					<select id="province" name="province">
						<option value="0">Please Select</option>
						<?php
						$mysqli = new mysqli("localhost", "root", "", "cfa_afghanistan");
						/* check connection */
						if (mysqli_connect_errno()) {
							printf("Connect failed: %s\n", mysqli_connect_error());
							exit();
						}	
						
						$query = "SELECT provinceID, provinceName from province";
						$result = $mysqli->query($query);	
						while($row = $result->fetch_array(MYSQLI_NUM))
						{ ?>
							<option value="<?php echo $row[0]; ?>"> <?php echo $row[1]; ?></option>
						<?php
						}
						?>
					</select> 				
				</td>
				
			</tr>		
			<tr>
				<td>District Name</td>
				<td>
					<select id="district" name="district" /> 
				</td>
			</tr>
			
			<tr>			
				<td>Start Date</td>
				
				<td>
					<input type="text" id="eventStartDate" name="eventStartDate" />
				</td>			
			</tr>
			<tr>			
				<td>End Date</td>
				<td>
					<input type="text" id="eventEndDate" name="eventEndDate" />
				</td>			
			</tr>
			<tr>			
				<td>Center</td>
				<td>
					<input type="text" id="center" name="center" />
				</td>			
			</tr>
			<tr>
				<td>Location</td>
				<td>
					<input type="text" id="location" name="location" />
				</td>
			</tr>
			<tr>			
				<td colspan="2">
					<input type="submit" value="Add Training" class="btn primary"/>
				</td>			
			</tr>			
		</table>			
	</form>
	</div>
 </div>
</body>
</html>
